import { Button } from "@/components/ui/button"
import { Check } from "lucide-react"
import Link from "next/link"

interface PricingCardProps {
  title: string
  price: string
  period: string
  description: string
  features: string[]
  ctaText: string
  accentColor: string
  featured?: boolean
  badge?: string
}

export default function PricingCard({
  title,
  price,
  period,
  description,
  features,
  ctaText,
  accentColor,
  featured = false,
  badge,
}: PricingCardProps) {
  return (
    <div
      className={`relative rounded-lg overflow-hidden ${
        featured ? "shadow-slack-md border-2 border-primary" : "shadow-slack-sm border border-gray-200"
      } bg-white hover:shadow-slack transition-shadow duration-300`}
    >
      {badge && (
        <div
          className="absolute top-0 right-0 px-4 py-1 text-xs font-medium text-white"
          style={{ backgroundColor: accentColor === "#2BAC76" ? "#2BAC76" : "#4A154B" }}
        >
          {badge}
        </div>
      )}
      <div className="p-8">
        <h3 className="text-xl font-bold text-gray-900 mb-2">{title}</h3>
        <div className="flex items-baseline mb-4">
          <span className="text-3xl font-bold text-gray-900">{price}</span>
          <span className="ml-1 text-muted-foreground">{period}</span>
        </div>
        <p className="text-muted-foreground mb-6">{description}</p>
        <Button
          className="w-full mb-8 py-6 rounded-lg"
          style={{
            backgroundColor: accentColor === "#2BAC76" ? "#2BAC76" : "#4A154B",
            color: "white",
          }}
          asChild={title === "Executive Circle"}
        >
          {title === "Executive Circle" ? <Link href="/apply/executive">{ctaText}</Link> : ctaText}
        </Button>
        <div className="space-y-4">
          {features.map((feature, index) => (
            <div key={index} className="flex items-start gap-3">
              <div
                className="h-5 w-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                style={{
                  backgroundColor: accentColor === "#2BAC76" ? "rgba(43, 172, 118, 0.1)" : "rgba(74, 21, 75, 0.1)",
                }}
              >
                <Check className="h-3 w-3" style={{ color: accentColor === "#2BAC76" ? "#2BAC76" : "#4A154B" }} />
              </div>
              <span className="text-muted-foreground">{feature}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
