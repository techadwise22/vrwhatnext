"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 w-full border-b border-gray-200 bg-white shadow-slack-sm">
      <div className="container flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="text-2xl font-bold text-primary">What Next?</span>
        </Link>
        <nav className="hidden md:flex gap-6 items-center">
          <Link href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium">
            About
          </Link>
          <Link href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium">
            Membership
          </Link>
          <Link href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium">
            Events
          </Link>
          <Link href="#" className="text-muted-foreground hover:text-primary transition-colors font-medium">
            Resources
          </Link>
          <Button className="bg-primary hover:bg-primary-600 text-white ml-2 rounded-lg" asChild>
            <Link href="/apply">Apply Now</Link>
          </Button>
        </nav>
        <button className="flex md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X className="h-6 w-6 text-primary" /> : <Menu className="h-6 w-6 text-primary" />}
        </button>
      </div>
      {isMenuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white">
          <div className="container px-4 py-4 flex flex-col gap-4">
            <Link
              href="#"
              className="text-muted-foreground hover:text-primary transition-colors py-2 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </Link>
            <Link
              href="#"
              className="text-muted-foreground hover:text-primary transition-colors py-2 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Membership
            </Link>
            <Link
              href="#"
              className="text-muted-foreground hover:text-primary transition-colors py-2 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Events
            </Link>
            <Link
              href="#"
              className="text-muted-foreground hover:text-primary transition-colors py-2 font-medium"
              onClick={() => setIsMenuOpen(false)}
            >
              Resources
            </Link>
            <Button
              className="bg-primary hover:bg-primary-600 text-white w-full mt-2 rounded-lg"
              asChild
              onClick={() => setIsMenuOpen(false)}
            >
              <Link href="/apply">Apply Now</Link>
            </Button>
          </div>
        </div>
      )}
    </header>
  )
}
