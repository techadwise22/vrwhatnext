"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"

const testimonials = [
  {
    quote:
      "What Next? has been instrumental in helping me navigate my transition from CFO to board advisor. The community and resources are unparalleled.",
    author: "Priya Sharma",
    title: "Former CFO, Tech Unicorn",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    quote:
      "The Executive Circle has connected me with policy makers and industry leaders I wouldn't have met otherwise. It's been worth every rupee.",
    author: "Rajiv Mehta",
    title: "Finance Director, Fortune 500",
    image: "/placeholder.svg?height=80&width=80",
  },
  {
    quote:
      "As a finance leader in my 30s, I was looking for guidance on scaling my influence. What Next? provided exactly that through mentorship and peer connections.",
    author: "Ananya Patel",
    title: "VP Finance, Growth-Stage Startup",
    image: "/placeholder.svg?height=80&width=80",
  },
]

export default function TestimonialCarousel() {
  const [current, setCurrent] = useState(0)
  const [autoplay, setAutoplay] = useState(true)

  const next = () => {
    setCurrent((current + 1) % testimonials.length)
  }

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length)
  }

  useEffect(() => {
    if (!autoplay) return

    const interval = setInterval(() => {
      next()
    }, 5000)

    return () => clearInterval(interval)
  }, [current, autoplay])

  return (
    <div className="relative max-w-4xl mx-auto">
      <div className="overflow-hidden rounded-lg bg-white p-8 md:p-12 shadow-slack border border-gray-200">
        <div
          className="transition-all duration-500 ease-in-out flex"
          style={{ transform: `translateX(-${current * 100}%)` }}
        >
          {testimonials.map((testimonial, index) => (
            <div key={index} className="w-full flex-shrink-0 px-4">
              <div className="flex flex-col items-center text-center">
                <div className="relative h-20 w-20 rounded-full overflow-hidden mb-6 border-2 border-primary-50 shadow-md">
                  <Image
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.author}
                    fill
                    className="object-cover"
                  />
                </div>
                <blockquote className="text-xl md:text-2xl text-gray-800 font-medium italic mb-6 bg-muted p-6 rounded-lg">
                  "{testimonial.quote}"
                </blockquote>
                <div>
                  <p className="font-medium text-gray-900">{testimonial.author}</p>
                  <p className="text-muted-foreground">{testimonial.title}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-center mt-6 gap-2">
        <button
          onClick={() => {
            prev()
            setAutoplay(false)
          }}
          className="p-2 rounded-full bg-white border border-gray-200 shadow-slack-sm hover:shadow-slack transition-shadow duration-300"
          aria-label="Previous testimonial"
        >
          <ChevronLeft className="h-5 w-5 text-gray-700" />
        </button>
        <div className="flex items-center gap-2">
          {testimonials.map((_, index) => (
            <button
              key={index}
              onClick={() => {
                setCurrent(index)
                setAutoplay(false)
              }}
              className={`h-2 rounded-full transition-all duration-300 ${
                current === index ? "bg-primary w-8" : "bg-gray-200 w-2"
              }`}
              aria-label={`Go to testimonial ${index + 1}`}
            />
          ))}
        </div>
        <button
          onClick={() => {
            next()
            setAutoplay(false)
          }}
          className="p-2 rounded-full bg-white border border-gray-200 shadow-slack-sm hover:shadow-slack transition-shadow duration-300"
          aria-label="Next testimonial"
        >
          <ChevronRight className="h-5 w-5 text-gray-700" />
        </button>
      </div>
    </div>
  )
}
